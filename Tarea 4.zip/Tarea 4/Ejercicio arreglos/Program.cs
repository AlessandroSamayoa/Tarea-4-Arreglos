﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_arreglos
{
    class Program
    {
        static void Main(string[] args)
        {  
            //Insertar nombres
            string[] nombres = new string[10];
            int a, b, c;
            a = 0;
            b = 0;
            c = 0;
            Console.WriteLine("Este es un arreglo vacio de 10 elementos que uds puede llenar con nombres");
            for(a=0;a<10;a++)
            {
                Console.WriteLine("Inserte el arreglo número {0}",b+1);
                Console.Write("{0}.",b+1);
                nombres[b] = Console.ReadLine();
                b++;
                
                Console.Clear();
            }
            Console.WriteLine();

            Console.WriteLine("Los datos ingresados en el arreglo son");
            foreach (string box in nombres)
            {

                Console.WriteLine("{0}.{1}", c + 1, box);
                c++;
            }
            Console.WriteLine("Presione la tecla 'B' para borrar los datos del arreglo");
            while (Console.ReadKey().Key != ConsoleKey.B) { }
            Console.Clear();

            //Borrar cualquien nombre
            int borrar;
            bool erase = true;
            while (erase)
            {
                Console.Clear();
                Console.WriteLine("Borrar datos del arreglo");
                Console.WriteLine("Presione cualquier número del 1 al 10 para borrar algún nombre del arreglo\no escriba el número '541' para 'salir' y modificar el arreglo");
                c = 0;
                foreach (string box in nombres)
                {

                    Console.WriteLine("{0}.{1}", c + 1, box);
                    c++;
                }
                Console.WriteLine();
                borrar = int.Parse(Console.ReadLine());
                if (borrar < 11 && borrar > 0)
                {
                    nombres[borrar - 1] = null;
                    erase = true;
                }
                else
                    if (borrar == 541)
                    {
                    erase = false;
                    }
                    else
                    { 
                        Console.WriteLine("El arreglo solo tiene 10 elementos, escriba bien el número que va a borrar");
                        erase = true;
                    }
                
                
            }

            //Insertar nombre
            Console.Clear();
            Console.WriteLine("A continuación podra insertar nombres en los contenedores vacios");
            int conteo, insert;
            for (conteo = 0; conteo < 10; conteo++)
            {
                insert = 0;
                foreach (string box in nombres)
                {

                    Console.WriteLine("{0}.{1}", insert + 1, box);
                    insert++;
                }
                if (nombres[conteo] == null)
                {
                    Console.WriteLine("El contenedor {0} esta vacio, escriba el nuevo elemento o dejelo en blanco", conteo + 1);
                    nombres[conteo] = Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("El contenedor {0} ya tiene un valor y es '{1}'\nPresione Enter para seguir", conteo + 1, nombres[conteo]);
                    while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                }
                Console.Clear();              
                
            }

            //Modificar arreglo
            bool repetir = true;
            while (repetir)
            {
                insert = 0;
                foreach (string box in nombres)
                {
                    Console.WriteLine("{0}.{1}", insert + 1, box);
                    insert++;
                }
                
                Console.WriteLine("\nA continuación modificara el arreglo");
                int modificar, porel;
                modificar = 0;
                porel = 0;
                string savename = null;

                Console.WriteLine("Seleccione el número del elemento que va a modificar");
                modificar = int.Parse(Console.ReadLine()) - 1;
                    if (modificar < 10 && modificar > 0)
                    {
                        savename = nombres[modificar];
                    }
                    

                    Console.WriteLine("Lo va modificar por el nombre de:");
                    porel = int.Parse(Console.ReadLine()) - 1;

                    if (modificar < 10 && modificar > 0)
                    { 
                        nombres[modificar] = nombres[porel];
                        Console.WriteLine("\nEl arreglo modificado es:");
                        nombres[porel] = savename;
                    }
                    else
                    {
                    Console.Clear();
                    Console.WriteLine("El rango del arreglo es de 1 a 10, Por favor escriba los números dentro de los rangos");
                    }



                    insert = 0;
                    foreach (string box in nombres)
                    {
                        Console.WriteLine("{0}.{1}", insert + 1, box);
                        insert++;
                    }
                    Console.WriteLine("Presione '1' para repetir la operación, o '2' para salir del programa\nLuego de escribir la operación, presione Enter");
                    int continuar = int.Parse(Console.ReadLine());

                    switch (continuar)
                    {
                        case 1:
                            repetir = true;
                            Console.Clear();
                            break;
                    
                        case 2:
                            repetir = false;
                            break;
                    
                        default:
                            Console.WriteLine("Selección invalida, presione cualquier tecla para regresar");
                            Console.ReadKey();
                            Console.Clear();
                            repetir = true;
                            break;
                    }
                
                

            }



            Console.WriteLine("A salido");
            Console.ReadKey();

        }
    }
}
